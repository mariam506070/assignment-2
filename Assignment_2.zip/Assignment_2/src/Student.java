public class Student extends Person{
    
    
  private static String status;
  
  
  public Student(String n,String addr,int phN,String eml,String stat)
  {
  super(n,addr,phN,eml);
  this.status=stat;
  }
  
  
  
//  public String toString()
//  {
//  return "name"+getName()+"address"+getAddress()+"phonenumber"+getPhoneNumber()+
//          "email"+getEmail()+"status"+status ;
//  }
  
    
}
