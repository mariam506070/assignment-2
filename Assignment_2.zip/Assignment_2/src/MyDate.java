
public class MyDate {
   
    public int year;
    public int month;
    public int day;
    
    public MyDate(int d,int m,int y)
    {
    this.day=d;
    this.month=m;
    this.year=y;
    
    }
    
//    @Override
//    public String toString()
//    {
//    return "day"+day+"month"+month+"year"+year;
//    
//    }
    
    
    
}
