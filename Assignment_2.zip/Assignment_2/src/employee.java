
public class employee extends Person{
    
    public String office;
    public double salary;
    public MyDate dateHired;
    
    
    public employee(String n,String addr,int phN,String eml,String offi,double sal, MyDate dateHin)
    {
    this.office=offi;
    this.salary=sal;
    this.dateHired=dateHin;
    }
    
    
    void display()
    {
    System.out.println( name+ address +phoneNumber +email+office+salary+dateHired );
    }
    
   // @Override
//    public String toString()
//    {
//    return "name"+getName()+"address"+getAddress()+"phonenumber"+getPhoneNumber()+
//          "email"+getEmail()+ "office"+office+"salary"+salary+"datehired"+dateHired;
//    }
    
    
}
