

public class Assignment_2 {

    
    public static void main(String[] args) {
         
         
      Student s=new Student("mina","Dear Elbarsha",013435235,"mina3@gmail.com","freshman") ; 
        s.getPhoneNumber();
      System.out.println(s.toString());
       
      MyDate mD=new MyDate(1,11,2021);
      
      
     
   
      employee e=new employee("marwan","Maloy",012447445,"marwan@gfh","felo",3500.0,d);
      e.getPhoneNumber();
      
 
      System.out.println(e.toString());
      
      
    }
    
    
    
    
}
