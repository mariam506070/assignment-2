import java.util.*;
public class Person {
    
    public String name;
    public String address;
    public int phoneNumber;
    public String email;
    
    
    
    public Person(String n,String addr,int phN,String eml)
    {
    this.name=n;
    this.address=addr;
    this.phoneNumber=phN;
    this.email=eml;                
    }
    
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String toString()
  {
return "name"+getName()+"address"+getAddress()+"phonenumber"+getPhoneNumber()+
"email"+getEmail();
    }
    
    
    
    
}
