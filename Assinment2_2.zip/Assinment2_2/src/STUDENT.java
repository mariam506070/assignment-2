
public class STUDENT {
    
   public String name;
   private int idSt;
   private double GPA;
   
   
    subject subject;
    address address;
    public STUDENT(String name , int id , double gpa , subject subject , address address )
    {
 
       this.name=name;
       this.idSt=id;
       this.GPA=gpa;
       this.subject=subject;
       this.address=address;
     
 }
  void display()
  {
      System.out.print("Name is :"+name+ "ID is :"+idSt+"GPA is : "+GPA);
      System.out.print( " the Subject is : "+ subject.toString());
      System.out.print(" the Address is :"+address.toString());
      
  }
    
    

   
}
