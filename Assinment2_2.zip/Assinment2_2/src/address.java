
public class address {
    
    private int streetNO;
    private String city;
    private String country;
    public address(int streetNO , String city , String country)
    {
        this.streetNO=streetNO;
        this.city=city;
        this.country=country;
        
    
}

}
