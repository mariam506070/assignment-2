
public class subject {
     private int id;
     private String name;
     private double hours;
    public subject(int id , String name , double hours)
    {
         this.id=id;
         this.name =name;
         this.hours=hours;
    }

}
